function setup() {
  createCanvas(500, 300);
}

function draw() {
  background(13,12,18);
  
  // packaman's shape and color
  fill(234,242,56)
  arc(50, 140, 80, 80, PI/8, PI + QUARTER_PI + QUARTER_PI + QUARTER_PI);
  // balls
  fill(234,242,56,240);
  rect(120,125,25,25,50);
  rect(180,125,25,25,50);
  rect(240,125,25,25,50);
  rect(300,125,25,25,50);
  rect(360,125,25,25,50);
  // packman's eye
  fill(0,0,0);
  circle(50,120,5);
  // barreira
  fill(45,35,163);
  rect(10,60,470,20,50);
  rect(460,0,20,80,50);
  noStroke();
  rect(10,200,470,20,50);
  rect(460,200,20,100,50);
  // vilan
  fill(7,224,227);
  arc(470, 150, 80, 80, PI,0);
  rect(430,150,300,30);
  // triangules on the vilian
  // triangules back
  fill(0);
  triangle(435,170,430,180,440,180);
  triangle(450,170,445,180,455,180);
  triangle(465,170,460,180,470,180);
  triangle(480,170,475,180,485,180);
  triangle(495,170,490,180,500,180);
  // triangules blues 
  // here I'm going to write the stuff for that
  
  
  // Vilian's eyes
  fill(255);
  arc(440, 150, 15,25, 0, 2*PI);
  arc(470, 150, 15,25, 0, 2*PI);  
  // eyeball
  fill(54,40,222);
  arc(436, 150, 7,13, 0, 2*PI); 
  arc(466, 150, 7,13, 0, 2*PI);
}