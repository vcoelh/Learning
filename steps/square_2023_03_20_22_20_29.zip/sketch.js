
let circleX=50;
let circleY=50;

function setup() {

createCanvas(400, 400);
  background(0);
}

function draw() {
  
  let c = random(0,255);
  let d = random(0,255);
  let e = random(0,255);
  
  
  
  
noStroke()
fill(c,d,e);
circle(circleX,circleY, 50)
  
if((circleX<300)&&(circleY===50)) {
  circleX++;

}
  
if(circleX===300){
   circleY++;
}  
if((circleX<=300)&&(circleY===300)){
  circleX--;
}
  
if((circleX===50)){
  circleY--;
}

  
}



//function mousePressed(){
//  circleX=0;
//}