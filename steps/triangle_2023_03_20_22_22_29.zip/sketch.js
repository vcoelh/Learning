let x =51;
let y =51;

function setup() {
  createCanvas(400, 400);
  background(0);
}


function draw() {

  fill(225)
  circle(x,y,50);
  stroke(225);
  
  if((x<350)&&(y<350)&&(x!=50)&&(y!=50)){
    x++;
    y++;
    console.log("step1")

  }    
  if((x<=350)&&(y===350)){
      x--;
    console.log("step2");
  }

 if((x===50 )&&(y>50)){
   y--;
   console.log("step3a")
 }
  
  
}

